'use strict';

console.log('Loading function');
var request = require('request');
var neo4j = require('neo4j');
var db = new neo4j.GraphDatabase('http://neo4j:zzzzz@http://34.239.129.68/:7474');


console.log("IN START");

exports.handler = (event, context, callback) => {


    // return;

    const done = (err, res) => callback(null, {
        statusCode: err ? '400' : '200',
        body: err ? err.message : JSON.stringify(res),
        headers: {
            'Content-Type': 'application/json',
        },
    });


    switch (event.httpMethod) {
        case 'GET':
            if(event.path == '/playerFunc'){
                console.log("IN GET");
                var my_rows;
                // let secondpormm = new Promise(function(resolve, reject) {
                // });


                db.cypher({
                    query: 'match (n:Player) return n',
                }, function (err, results) {
                    if (err) throw err;
                    var result = results[0];
                    if (!result) {
                        console.log('No user found.');
                    } else {
                        console.log(result)
                        console.log("BETWEEN")
                        console.log(result['u'])
                        var user = result['u'];
                        console.log(JSON.stringify(user, null, 4));
                        callback(null, {
                            statusCode: '200',
                            body: JSON.stringify(user, null, 4),
                            headers: {
                                'Content-Type': 'application/json',
                            }
                        })
                    }
                });



            } else if(event.path.includes('/playerFunc/')){ // this is for /companyFunc/:id
              console.log("IN getting company ID");
              console.log(event.path.substr(event.path.lastIndexOf("/") + 1))
              var my_rows;
              let firstpormmmPage = new Promise(function(resolve, reject) {
                  connection.query("SELECT * from employee WHERE employeeId=?", event.path.substr(event.path.lastIndexOf("/") + 1),  function (error, rows) {
                    console.log(error);
                      console.log(rows);
                      my_rows = rows;
                      if (!error) {
                          connection.end();
                          resolve(1);
                      }

                  });
              });
              firstpormmmPage.then(function() {
                return getAllMethod(my_rows);
              });
            }
            break;
        case 'POST':
            console.log("IN POST");
            var my_rows;
            var bod = JSON.parse(event.body);
            snsPublish('In employeeFunc: POST', {arn: 'arn:aws:sns:us-east-1:099711494433:LambdaTest'});
            let postEmployeePromise = new Promise(function(resolve, reject) {
              connection.query("INSERT INTO employee (personId, companyId, salary, title) VALUES (?, ?, ?, ?)", [bod.personId, bod.companyId, bod.salary, bod.title], function (error, rows) {
                console.log(error);
                console.log(rows);
                my_rows = rows;
                console.log(event.headers['idem-key'])
                console.log(JSON.stringify(my_rows))
                connection.query("INSERT INTO idem (`key`, resp) VALUES (?, ?)", [event.headers['idem-key'], JSON.stringify(my_rows)], function (error2, rows2) {
                  if (!error2) {
                      console.log("in error block")
                      console.log(error2)
                      console.log(rows2)
                      connection.end();
                      resolve(1);
                  }
                  console.log("outside of error block")
                  console.log(error2)
                  console.log(rows2)
                });
                // if (!error) {
                //     connection.end();
                //     resolve(1);
                // }
              });
            });
            postEmployeePromise.then(function() {
              console.log(my_rows);
              callback(null, {
                  statusCode: '200',
                  // body: err ? err.message : JSON.stringify(res),
                  body: JSON.stringify(my_rows),
                  headers: {
                      'Content-Type': 'application/json',
                  //    'etag': etag(JSON.stringify(my_rows))
                  }
              })
            });
            break;
        case 'DELETE':
            console.log("IN DELETE");
            console.log("getting key from header:");
            console.log(event.headers['idem-key']);
            console.log()
            snsPublish('In employeeFunc.: DELETE', {arn: 'arn:aws:sns:us-east-1:099711494433:LambdaTest'});
            var my_rows;
            let firstpormmm2 = new Promise(function(resolve, reject) {
                connection.query("DELETE from employee where employeeId="+String(event.path.substr(event.path.lastIndexOf("/") + 1)), function (error, rows) {
                    console.log(error);
                    console.log(rows);
                    my_rows = rows;
                    connection.query("INSERT INTO idem (`key`, resp) VALUES (?, ?)", [event.headers['idem-key'], JSON.stringify(my_rows)], function (error2, rows2) {
                  if (!error2) {
                      console.log("in error block")
                      console.log(error2)
                      console.log(rows2)
                      connection.end();
                      resolve(1);
                  }
                  console.log("outside of error block")
                  console.log(error2)
                  console.log(rows2)
                });
                    // if (!error) {
                    //     connection.end();
                    //     resolve(1);
                    // }

                });
            });
            firstpormmm2.then(function() {
                console.log(my_rows);
                callback(null, {
                    statusCode: '200',
                    // body: err ? err.message : JSON.stringify(res),
                    body: JSON.stringify(my_rows),
                    headers: {
                        'Content-Type': 'application/json',
                      //  'etag': etag(JSON.stringify(my_rows))
                    }
                })
            });
            break;
        case 'PUT': // this is for PUT on companyFunc/:id
         console.log("IN PUT");
            snsPublish('In employeeFunc: PUT', {arn: 'arn:aws:sns:us-east-1:099711494433:LambdaTest'});
            var my_rows;
            let putEmployeePromise = new Promise(function(resolve, reject) {
            var bod = JSON.parse(event.body);
            connection.query("UPDATE employee SET personId=?, companyId=?, salary=?, title=? WHERE employeeId=?", [bod.personId, bod.companyId, bod.salary, bod.title, event.path.substr(event.path.lastIndexOf("/") + 1)], function (error, rows) {
                  console.log(error);
                  console.log(rows);
                  my_rows = rows;
                  connection.query("INSERT INTO idem (`key`, resp) VALUES (?, ?)", [event.headers['idem-key'], JSON.stringify(my_rows)], function (error2, rows2) {
                  if (!error2) {
                      console.log("in error block")
                      console.log(error2)
                      console.log(rows2)
                      connection.end();
                      resolve(1);
                  }
                  console.log("outside of error block")
                  console.log(error2)
                  console.log(rows2)
                });
                  // if (!error) {
                  //     connection.end();
                  //     resolve(1);
                  //   }
                });
            });
            putEmployeePromise.then(function() {
              console.log(my_rows);
              callback(null, {
                statusCode: event.headers == null ? '200' : event.headers.etag == null  ? '200' : etag(JSON.stringify(my_rows)) == JSON.stringify(event.headers.etag) ? '304' : '200',
                  // body: err ? err.message : JSON.stringify(res),
                  body: JSON.stringify(my_rows),
                  headers: {
                      'Content-Type': 'application/json',
                      'etag': etag(JSON.stringify(my_rows))
                  }
              })
            });
            break;
        default:
            console.log("IN DEFAULT");
            done(new Error(`Unsupported method "${event.httpMethod}"`));
    }
  };
